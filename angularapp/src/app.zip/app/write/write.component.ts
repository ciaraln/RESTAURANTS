import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Router, Params } from '@angular/router';


@Component({
  selector: 'app-write',
  templateUrl: './write.component.html',
  styleUrls: ['./write.component.css']
})
export class WriteComponent implements OnInit {

  newReview: any;
  allReviews: any;
  err = "";
  id: any;
  constructor(private _http: HttpService, private _route: ActivatedRoute, private _router: Router) { }

  ngOnInit() {
    this.newReview = { id:"", name: "", type: "" }
  }

  sendallReviews() {
    let observabele = this._http.getReviews();
    observabele.subscribe(data => {
      console.log(" All the Reviews", data)
      this.allReviews = data
    })
  }

  onSubmit() {
    let observable = this._http.addReview(this.id,this.newReview);
    observable.subscribe(response => {
      if (response == "Review validation failed: name: Review name required") {
        this.err = "Review name must have at least 3 characters, come you can do it! Chilli's was awesome. etc...";
        this.refresh();
      } else if (response == "You failed your Review! Validations Review must have at least 3 characters") {
        this.err = "Really, Review must have at least 3 characters";
        this.refresh();
      } else {
        console.log(response);
        this.newReview= response;
        this.goHome();
      }
    })
  }

  goHome() {
    this._router.navigate(['/home']);
  }

  refresh() {
    this._router.navigate(['/write']);
  }

}
